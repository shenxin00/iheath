#include "transform.h"
#include <avr/io.h>
#include <util/delay.h>
#include "gps.h"
#include "lcd.h"

unsigned char trans_buffer[BUFFER_LONG]={0};

unsigned char trans_clr_buf(unsigned char *buffer)
{
	unsigned char i;
	for(i=0;i<BUFFER_LONG;i++,buffer++)
	{
		*buffer='\0';
	}
	return 0;
}

unsigned char* trans_time(void)
{
	unsigned char temp=0;
	trans_clr_buf(trans_buffer);
	trans_buffer[0]='T';
	trans_buffer[1]=':';
	temp=(GPRMC_Locat_P[0][0]-'0')*10;
	temp+=GPRMC_Locat_P[0][1]-'0';
	temp+=8;
	temp%=24;
	trans_buffer[2]='0'+temp/10;
	trans_buffer[3]='0'+temp%10;
	trans_buffer[4]=trans_buffer[7]=':';
	trans_buffer[5]=GPRMC_Locat_P[0][2];
	trans_buffer[6]=GPRMC_Locat_P[0][3];
	trans_buffer[8]=GPRMC_Locat_P[0][4];
	trans_buffer[9]=GPRMC_Locat_P[0][5];
	trans_buffer[10]=trans_buffer[11]=trans_buffer[12]=' ';
	if(GPRMC_Locat_P[1][0]=='V')
		trans_buffer[13]='F';
	else
	{
		if(GPRMC_Locat_P[1][0]=='A')
			trans_buffer[13]='T';
		else
			trans_buffer[13]='E';
	}
	return trans_buffer;
}

unsigned char* trans_latitude(void)
{
	unsigned int temp=0;
	trans_clr_buf(trans_buffer);
	trans_buffer[0]=GPRMC_Locat_P[3][0];
	trans_buffer[1]=':';
	trans_buffer[2]=GPRMC_Locat_P[2][0];
	trans_buffer[3]=GPRMC_Locat_P[2][1];
	trans_buffer[4]='\\';					////****************��
	trans_buffer[5]=GPRMC_Locat_P[2][2];
	trans_buffer[6]=GPRMC_Locat_P[2][3];
	trans_buffer[7]='\'';
	temp=(GPRMC_Locat_P[2][5]-'0')*100;
	temp+=(GPRMC_Locat_P[2][6]-'0')*10;
	temp+=GPRMC_Locat_P[2][7]-'0';
	temp*=6;
	trans_buffer[8]=temp/1000+'0';
	trans_buffer[9]=temp%1000/100+'0';
	trans_buffer[10]='\"';
	return trans_buffer;

}

unsigned char* trans_longitude(void)
{
	unsigned int temp=0;
	trans_clr_buf(trans_buffer);
	trans_buffer[0]=GPRMC_Locat_P[5][0];
	trans_buffer[1]=':';
	trans_buffer[2]=GPRMC_Locat_P[4][0];
	trans_buffer[3]=GPRMC_Locat_P[4][1];
	trans_buffer[4]=GPRMC_Locat_P[4][2];
	trans_buffer[5]='\\';					////****************��
	trans_buffer[6]=GPRMC_Locat_P[4][3];
	trans_buffer[7]=GPRMC_Locat_P[4][4];
	trans_buffer[8]='\'';
	temp=(GPRMC_Locat_P[4][6]-'0')*100;
	temp+=(GPRMC_Locat_P[4][7]-'0')*10;
	temp+=GPRMC_Locat_P[4][8]-'0';
	temp*=6;
	trans_buffer[9]=temp/1000+'0';
	trans_buffer[10]=temp%1000/100+'0';
	trans_buffer[11]='\"';
	return trans_buffer;
}

unsigned char* trans_speed(void)
{
	trans_clr_buf(trans_buffer);
	unsigned long temp=0,count=1;
	unsigned char i,j,dot,speed_long;
	trans_buffer[0]='V';
	trans_buffer[1]=':';
	for(dot=0;dot<5;dot++)						//���ڴ����Ƕ���С�������Լ���DOTλ�ã�λ��Ϊʵ���������ڵ�λ��
	{
		if(GPRMC_Locat_P[6][dot]=='.')
			break;
	}
	for(i=0,temp=0;i<5;i++)							//���ַ���ת��Ϊ�����֣�ȥ��DOT
	{
		temp*=10;
		temp+=GPRMC_Locat_P[6][i]-'0';
		if(++i==dot)
			continue;
		else
			i--;
	}
	temp*=1852;									//���ڻ���ΪKM/H
	temp/=1000;									//ȥ��1852������ķŴ���
	dot=4-dot;									//С���������λ��
	for(speed_long=0,count=1;speed_long<13;speed_long++)//�������ݳ��ȣ�ʵ�ʳ���Ϊspeed_long��ֵ
	{
		if(temp/count==0)
			break;
		else
		{
			count*=10;
		}
	}
	if(speed_long>dot)
	{
		i=speed_long+6;
	}
	else
	{
		i=dot+7;
	}
	trans_buffer[i--]='h';
	trans_buffer[i--]='/';
	trans_buffer[i--]='m';
	trans_buffer[i--]='k';
	for(j=((dot>speed_long)?speed_long:dot);j>0;j--)
	{
		trans_buffer[i--]=temp%10+'0';
		temp/=10;
	}
	if(speed_long>dot)
	{
		trans_buffer[i--]='.';
		while(temp!=0)
		{
			trans_buffer[i--]=temp%10+'0';
			temp/=10;
		}
	}
	else
	{
		for(j=dot-speed_long;j>0;j--)
		{
			trans_buffer[i--]='0';
		}
		trans_buffer[i--]='.';
		trans_buffer[i--]='0';
	}
	trans_buffer[i--]=':';
	trans_buffer[i--]='V';
	return trans_buffer;
}

unsigned char* trans_course(void)
{
	trans_clr_buf(trans_buffer);
	trans_buffer[0]='C';
	trans_buffer[1]=':';
	trans_buffer[2]=GPRMC_Locat_P[7][0];
	trans_buffer[3]=GPRMC_Locat_P[7][1];
	trans_buffer[4]=GPRMC_Locat_P[7][2];
	trans_buffer[5]=GPRMC_Locat_P[7][3];
	trans_buffer[6]=GPRMC_Locat_P[7][4];
	trans_buffer[7]='\\';
	return trans_buffer;
}

unsigned char* trans_date(void)
{
	trans_clr_buf(trans_buffer);
	unsigned char temp,day,month,year,leap_year=0;
	trans_buffer[0]='D';
	trans_buffer[1]=':';
	trans_buffer[4]=trans_buffer[7]='-';
	temp=(GPRMC_Locat_P[0][0]-'0')*10;
	temp+=GPRMC_Locat_P[0][1]-'0';
	temp+=8;
	if(temp>=24)
	{
		day=(GPRMC_Locat_P[8][0]-'0')*10;
		day+=GPRMC_Locat_P[8][1]-'0';
		month=(GPRMC_Locat_P[8][2]-'0')*10;
		month+=GPRMC_Locat_P[8][3]-'0';
		year=(GPRMC_Locat_P[8][4]-'0')*10;
		year+=GPRMC_Locat_P[8][5]-'0';
		if((year%4==0 && year%100!=0))//||(year%400==0))		//the year is between 2000 to 2099 :-(
			leap_year=29;
		else
			leap_year=28;
		temp=0;
		switch(month)
		{
			case 1	:
			case 3	:
			case 5	:
			case 7	:
			case 8	:
			case 10	:
			case 12	:
				if(day/31==1)
				{
					day=1;
					temp=1;
				}
				break;
			case 4	:
			case 6	:
			case 9	:
			case 11	:
				if(day/30==1)
				{
					day=1;
					temp=1;
				}
				break;
			case 2	:
				if(day/leap_year==1)
				{
					day=1;
					temp=1;
				}
				break;
			default : break;
		}
		month+=temp;
		temp=0;
		if(month==13)
		{
			month=1;
			temp=1;
		}
		year+=temp;
		trans_buffer[8]=day/10+'0';	//day
		trans_buffer[9]=day%10+'0';
		trans_buffer[5]=month/10+'0';	//month
		trans_buffer[6]=month%10+'0';
		trans_buffer[2]=year/10+'0';
		trans_buffer[3]=year%10+'0';	//year
	}
	else
	{
		trans_buffer[8]=GPRMC_Locat_P[8][0];	//day
		trans_buffer[9]=GPRMC_Locat_P[8][1];
		trans_buffer[5]=GPRMC_Locat_P[8][2];	//month
		trans_buffer[6]=GPRMC_Locat_P[8][3];
		trans_buffer[2]=GPRMC_Locat_P[8][4];
		trans_buffer[3]=GPRMC_Locat_P[8][5];	//year
	}
	return trans_buffer;
}

