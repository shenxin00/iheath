#ifndef	__DISPLAY_H__
#define	__DISPLAY_H__

#define GPSOviData 	usbOviData

extern unsigned char displayMode;
extern unsigned char displayRecordUnit;
extern unsigned char displayRecordFreq;
extern unsigned int displayRecordAdd;
extern unsigned char displayRecordStart;
extern unsigned char displayRecordOverflow;


extern unsigned char display(void);
extern unsigned char displayRecordMode(void);
extern unsigned char displayRecordFun(void);

unsigned char displayMode00(void);
unsigned char displayMode10(void);
unsigned char displayMode11(void);
unsigned char displayMode12(void);
unsigned char displayMode20(void);
unsigned char displayMode21(void);
unsigned char displayMode22(void);

extern unsigned char displayReadOvi(void);


#endif
