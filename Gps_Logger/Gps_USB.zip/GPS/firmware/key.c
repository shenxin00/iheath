#include "key.h"
#include <avr/io.h>
#include <util/delay.h>
#include "lcd.h"
#include "eeprom.h"
#include "display.h"
#include "usbconfig.h"
#include <avr/interrupt.h>
#include "usbdrv.h"

static unsigned char keyOld=KEY_NULL;

void keyInit(void)
{
	DDRC&=0xC7;
	PORTC|=0x38;
}
unsigned char keyRead(void)
{
	unsigned char keyValue=PINC;
	keyValue&=KEY_NULL;
	keyValue|=0x07;
	if(keyValue==KEY_NULL)
	{
		keyOld=KEY_NULL;
		return KEY_NULL;
	}
	_delay_ms(50);
	if(keyOld==keyValue)
		return KEY_NULL;
	keyOld=keyValue;
	keyEvent(keyValue);
	return keyValue;
}

unsigned char keyEvent(unsigned char keyValue)//此处只是触发按键事件，显示事件由display函数
{
	switch(keyValue)
	{
		case KEY_LEFT:
			switch(displayMode)
			{
				case 0x11:displayRecordAdd=0x00;displayRecordOverflow=false;displayMode=0x12;break;//EEPROM是否擦除
				case 0x12:displayRecordMode();displayMode=0x12;break;//处理Record记录频率
				case 0x13:displayRecordStart=true;displayMode=0x00;break;
				//---------------------------------
				case 0x21:usbDeviceDisconnect();
						  _delay_ms(100);
						  usbDeviceConnect();
						  sei();
						  displayMode=0x22;break;
				//case 0x22:displayMode=0x22;break;
				default:return 0;//debug code
			};
			break;
		case KEY_RIGHT:
			switch(displayMode)
			{
				case 0x10:displayMode=0x11;break;
				case 0x11:displayMode=0x12;break;
				case 0x12:displayMode=0x13;break;//此处处理Frequent 事件
				case 0x13:displayRecordStart=false;displayMode=0x00;break;
				//---------------------------------
				case 0x20:displayMode=0x21;break;//必须将记录功能关闭
				case 0x21:displayMode=0x00;break;
				case 0x22:cli();usbDeviceDisconnect();displayMode=0x00;break;
				default:return 0;//debug code
			};
			break;
		case KEY_MENU:
			switch(displayMode)
			{
				case 0x00:displayMode=0x10;break;
				case 0x10:displayMode=0x20;break;
				case 0x20:displayMode=0x00;break;//此处处理Frequent 事件
				//---------------------------------
				default:return 0;//debug code
			};
			break;
		default: displayMode=0x00;
	}
	return 0;
}
