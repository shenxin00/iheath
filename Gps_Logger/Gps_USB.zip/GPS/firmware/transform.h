#ifndef __TRANSFORM_H__
#define __TRANSFORM_H__



#define BUFFER_LONG 15

extern unsigned char* trans_time(void);
extern unsigned char* trans_latitude(void);
extern unsigned char* trans_course(void);
extern unsigned char* trans_date(void);
extern unsigned char* trans_longitude(void);
extern unsigned char* trans_speed(void);

#endif
