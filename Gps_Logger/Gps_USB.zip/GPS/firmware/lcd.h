#ifndef __LCD_H__
#define __LCD_H__

//LCD:PORTB:SCK,MOSI,SCE
//	  PORTD:C/D,RST,BL
#define LCD_LIGHT 			5	//D
#define LCD_RESET 			6	//D
#define LCD_DATE_CMD		7	//D
#define LCD_SCE				0	//B
#define LCD_MOSI			3	//B
#define LCD_SCK				5	//B

#define LCD_LIGHT_ON() 		PORTD|=(1<<LCD_LIGHT)		//HIGH EN
#define LCD_LIGHT_OFF() 	PORTD&=~(1<<LCD_LIGHT)

#define LCD_RESET_ON()		PORTD&=~(1<<LCD_RESET)		//LOW EN
#define LCD_RESET_OFF()		PORTD|=(1<<LCD_RESET)

#define LCD_WRITE_DATE()	PORTD|=(1<<LCD_DATE_CMD)	//HIGH EN
#define LCD_WRITE_CMD()		PORTD&=~(1<<LCD_DATE_CMD)	//LOW EN

#define LCD_SCE_ON()		PORTB&=~(1<<LCD_SCE);PORTB |= (1<<EEPROM_SCE)		//LOW EN
#define LCD_SCE_OFF()		PORTB|=(1<<LCD_SCE)

#define LCD_PORT_INI()		DDRB|=((1<<LCD_SCE)|(1<<LCD_MOSI)|(1<<LCD_SCK));\
							DDRD|=((1<<LCD_DATE_CMD)|(1<<LCD_RESET)|(1<<LCD_LIGHT))
//??????????????????????????------------------?????????


extern void lcdInitialize();
extern void lcdClearBuffer(unsigned char * buffer);
extern void lcdDisplayAll(unsigned char * buffer);
//extern void lcd_write_pixel(unsigned char x,unsigned char y,unsigned char val);
//extern unsigned char lcd_read_pixel(unsigned char x,unsigned char y);
extern unsigned char lcdWriteString(const unsigned char* string,unsigned char x,unsigned char y);
extern void lcdSpiSet();

extern unsigned char lcdBuffer[504];



#endif
