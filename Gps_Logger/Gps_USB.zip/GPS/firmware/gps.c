#include "gps.h"
#include "uart.h"
#include <avr/pgmspace.h>   /* required by usbdrv.h */
#include "usbconfig.h"
#include "key.h"
#include "display.h"
#include "usbtrans.h"
/*
$GPRMC,060746,A,3019.2064,N,12020.2736,E,0.070,91.3,240110,4.8,W*5B
123456_123456_1_123456789_1_1234567890_1_12345_1234_123456_123_1234
0123456789012345678901234567890123456789012345678901234567890123456789''
0			1			2		3		4			5			6
*/
GPRMC_t GPRMC={{'0','6','0','7','4','6',','},{'A',','},{'3','0','1','9','.','2','0','6','4',','},{'N',','},{'1','2','0','2','0','.','2','7','3','6',','},{'E',','},{'0','.','0','7','0',','},{'1','0','0','.','3',','},{'2','4','0','1','1','0',','},{'1','1','4','.','8',','},{'W',','}};

//unsigned char GPSOviData[USB_OVI_REP_LEN]="880819101112100311114930000001000010";//使用格林威治时间
//										  yymmddhhmmssyymmddhhmmssllllllhhhhhh
//										  012345678901234567890123456789012345678		total:36
//										  0         1         2         3

unsigned char GPRMC_Locat_L[11]={GPRMC_UTCTime_L,GPRMC_State_L,GPRMC_Latitude_L,
										GPRMC_Latitude_NS_L,GPRMC_Longitutude_L,
										GPRMC_Longitude_EW_L,GPRMC_Speed_L,GPRMC_Course_L,
										GPRMC_UTCdate_L,GPRMC_MagicDec_L,GPRMC_MagicDec_EW_L
										};

unsigned char *GPRMC_Locat_P[11]={GPRMC.GPRMC_UTCTime,
								GPRMC.GPRMC_State,
								GPRMC.GPRMC_Latitude,
								GPRMC.GPRMC_Latitude_NS,
								GPRMC.GPRMC_Longitude,
								GPRMC.GPRMC_Longitude_EW,
								GPRMC.GPRMC_Speed,
								GPRMC.GPRMC_Course,
								GPRMC.GPRMC_UTCdate,
								GPRMC.GPRMC_MagicDec,
								GPRMC.GPRMC_MagicDec_EW
								};
/*****************************************************************************
unsigned char GPRMC_ErrorCount=0; //The variable count the number fo the error
*****************************************************************************/


/*Receive the GPRMC data from the GPS,if the data is error,
 the function will return 1,else return 0 .But this function
 will not return until it receive the GPRMC package.:-)*/
//unsigned int GPRMCMessageLen=10;
//-----------------------------------------------

unsigned char GPRMC_Receive()
{
	unsigned char flag=0,i,j,temp;		//flag ,if the length of the received data is unequal to standard				
	while(GPRMC_Package_Check()==0)		//这个东西相当耗时
	{//?????????????????????????????????
		//keyRead();	//this flag will be set;
		//display();此句有点问题
	}
	for(i=0;i<GPRMC_NUM;i++)
	{	
		for(j=0,flag=0;j<GPRMC_Locat_L[i];j++)
		{
			if(flag==1)					//the remained bit will be filled with '0' 
			{
				GPRMC_Locat_P[i][j]='0';
			}
			else
			{
				temp=USART_Receive();
				if(j!=0 && temp==',')		//find the ',' at the end of the data and will be replaced by 
				{							//'0'
					GPRMC_Locat_P[i][j]='0';
					flag=1;
				}
				else 
					if(j==0 && temp==',')	//find the ', at the begin of the date and will be replaced by'
					{						//next data
						GPRMC_Locat_P[i][j]=USART_Receive();
					}
					else					//the normal data will be saved
					{
						GPRMC_Locat_P[i][j]=temp;
					}
			}
		}
		GPRMC_Locat_P[i][--j]=',';				//change it in 2010.3.14 
	}
	return 0;	
}

/*this function check the receive data
if it is the  package head it will return 1
else it will return  0;    
              */
unsigned char GPRMC_Package_Check()
{
	if(USART_Receive()!='$') return 0;
	if(USART_Receive()!='G') return 0;
	if(USART_Receive()!='P') return 0;
	if(USART_Receive()!='R') return 0;
	if(USART_Receive()!='M') return 0;
	if(USART_Receive()!='C') return 0;
	else
		return 1;		
}
