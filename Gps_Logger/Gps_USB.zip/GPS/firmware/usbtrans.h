#ifndef	__USBTRANS_H__
#define	__USBTRANS_H__

#include"usbconfig.h"


extern unsigned char usbOviData[USB_OVI_REP_LEN];
extern void usbMode(void);

#endif
