#include "usbtrans.h"
#include <avr/io.h>
#include <avr/interrupt.h>  /* for sei() */
#include <util/delay.h>     /* for _delay_ms() */

#include <avr/pgmspace.h>   /* required by usbdrv.h */
#include "usbdrv.h"
#include "usbconfig.h"
#include "gps.h"
#include "lcd.h"
#include "eeprom.h"
//static uchar usbGpsData[USB_GPS_REP_LEN]="$GPRMC,060746,A,3019.2064,N,12020.2736,E,0.070,91.3,240110,4.8,W*5B";

PROGMEM char usbHidReportDescriptor[22] = {    /* USB report descriptor */
    0x06, 0x00, 0xff,              // USAGE_PAGE (Generic Desktop)
    0x09, 0x01,                    // USAGE (Vendor Usage 1)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x26, 0xff, 0x00,              //   LOGICAL_MAXIMUM (255)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x95, 0x80,                    //   REPORT_COUNT (128)
    0x09, 0x00,                    //   USAGE (Undefined)
    0xb2, 0x02, 0x01,              //   FEATURE (Data,Var,Abs,Buf)
    0xc0                           // END_COLLECTION
};

PROGMEM uchar usbFailData[20]="The Data is Error! ";


uchar usbOviData[USB_OVI_REP_LEN]="880819101112100311114930000001000010";//利用格林威治时间
//								   yymmddhhmmssyymmddhhmmssllllllhhhhhh
//								   012345678901234567890123456789012345678		total:36
//								   0         1         2         3
//										  						  count from 1 to sizeof(unsigned int)
//PROGMEM uchar test[USB_OVI_REP_LEN]="880819101112100311114930000001000010";//利用格林威治时间
//										  yymmddhhmmssyymmddhhmmssllllllhhhhhh
//										  012345678901234567890123456789012345678		total:36
//										  0         1         2         3
//										  						  count from 1 to sizeof(unsigned int)
static uchar*	 usbDataPt=usbFailData;
//static uchar	 usbDataLen=USB_ERR_REP_LEN;
static uchar    currentAddress=0;
static uchar    bytesRemaining;

//int usbMessageCurrent=0x00;//from 1 to the lagest NO,

/* ------------------------------------------------------------------------- */

/* usbFunctionRead() is called when the host requests a chunk of data from
 * the device. For more information see the documentation in usbdrv/usbdrv.h.
 */
uchar   usbFunctionRead(uchar *data, uchar len)
{
    if(len > bytesRemaining)
        len = bytesRemaining;
    uchar i;
    for(i=0;i<len;i++)
    {
    	data[i]=usbDataPt[currentAddress+i];
    }
    currentAddress += len;
    bytesRemaining -= len;
    return len;
}


/* usbFunctionWrite() is called when the host sends a chunk of data to the
 * device. For more information see the documentation in usbdrv/usbdrv.h.
 */
 

/* ------------------------------------------------------------------------- */

usbMsgLen_t usbFunctionSetup(uchar data[8])
{
	usbRequest_t    *rq = (void *)data;
	unsigned char usbReportID=rq->wValue.bytes[0];
	unsigned int usbMessageCurrent;
	
    if((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS)
    {    /* HID class request */
        if(rq->bRequest == USBRQ_HID_GET_REPORT)
        {  /* wValue: ReportType (highbyte), ReportID (lowbyte) */
            /* since we have only one report type, we can ignore the report-ID */
            if(usbReportID==USB_GPS_REP_NUM )
            {
				usbMessageCurrent=(unsigned int)rq->wIndex.word;
				eepromSpiReadBlock((unsigned int)usbMessageCurrent*EEPROM_PAGE_SIZE,(unsigned char *) &GPRMC,USB_GPS_REP_LEN);
				usbDataPt=(unsigned char*)& GPRMC;
            	bytesRemaining=USB_GPS_REP_LEN;
            	currentAddress=0;
            	return USB_NO_MSG;//此数据为当前正在传输数据
            }
            else if(usbReportID==USB_OVI_REP_NUM)
            {
            	eepromSpiReadBlock((unsigned int)0,(unsigned char *)usbOviData,USB_OVI_REP_LEN);
            	usbDataPt=(unsigned char*)usbOviData;
            	bytesRemaining=USB_OVI_REP_LEN;
            	currentAddress=0;
            	return USB_NO_MSG;
            }
            usbDataPt=usbFailData;
            bytesRemaining=USB_ERR_REP_LEN;
            currentAddress=0;
            return USB_NO_MSG;
              /* use usbFunctionRead() to obtain data */
        }
    }
    else
    {
        /* ignore vendor type requests, we don't use any */
    }
    return 0;
}

