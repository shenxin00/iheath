#include "gps.h"
#include "lcd.h"
#include "usbtrans.h"
#include "eeprom.h"
#include "usbconfig.h"
#include "display.h"
#include "uart.h"
#include "key.h"
#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h> 
#include "usbdrv.h"


//static unsigned char test[USB_OVI_REP_LEN]="880819101112100311114930000001000010";

#ifndef	F_CPU
	#define F_CPU 12000000UL
#endif

#ifndef	BAUD
	#define BAUD   4800
#endif

int main()
{
	LCD_LIGHT_ON();
	_delay_ms(10);
	LCD_LIGHT_OFF();
	lcdInitialize();
	usbInit();
	USART_Init(R_UBRR);
	eepromSpiInitialize();
	eepromSpiBlockProtection(0);
	keyInit();
	displayReadOvi();
    usbDeviceDisconnect();  /* enforce re-enumeration, do this while interrupts are disabled! */ 
	_delay_ms(50);//usbDeviceConnect();
	LCD_LIGHT_ON();
	_delay_ms(10);
	LCD_LIGHT_OFF();
	for(;;)
	{
		if(displayMode==0x00)
		{
			GPRMC_Receive();
			displayRecordFun();
		}
		display();
		keyRead();
	}
    return 0;
}

