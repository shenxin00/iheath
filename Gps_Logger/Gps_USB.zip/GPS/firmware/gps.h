#ifndef __GPS_H__
#define __GPS_H__

#include "usbconfig.h"
/*the longth of the GPRMC data*/
#define GPRMC_UTCTime_L 		7
#define GPRMC_State_L 			2
#define GPRMC_Latitude_L 		10
#define GPRMC_Latitude_NS_L 	2
#define GPRMC_Longitutude_L 	11
#define GPRMC_Longitude_EW_L 	2
#define GPRMC_Speed_L 			6
#define GPRMC_Course_L 			6
#define GPRMC_UTCdate_L 		7
#define GPRMC_MagicDec_L 		6
#define GPRMC_MagicDec_EW_L 	2
#define GPRMC_NUM				11								//The number of GPRMC element


typedef struct GPRMCStruct
{
	unsigned char GPRMC_UTCTime[GPRMC_UTCTime_L];				//The time hhmmss
	unsigned char GPRMC_State[GPRMC_State_L];					//Is the GPS have the signal
	unsigned char GPRMC_Latitude[GPRMC_Latitude_L];				//The latitude ddmm.mmmm
	unsigned char GPRMC_Latitude_NS[GPRMC_Latitude_NS_L];		// The North or South
	unsigned char GPRMC_Longitude[GPRMC_Longitutude_L];			//The longtitude ddmm.mmmm
	unsigned char GPRMC_Longitude_EW[GPRMC_Longitude_EW_L];		//The East or West
	unsigned char GPRMC_Speed[GPRMC_Speed_L]; 					//The Speed 000.0~359.9
	unsigned char GPRMC_Course[GPRMC_Course_L];					//The Course 000.0~359.9
	unsigned char GPRMC_UTCdate[GPRMC_UTCdate_L];				//The UTC date
	unsigned char GPRMC_MagicDec[GPRMC_MagicDec_L];				// The magnetic declination
	unsigned char GPRMC_MagicDec_EW[GPRMC_MagicDec_EW_L];
} GPRMC_t;

extern GPRMC_t GPRMC;
//extern  PROGMEM GPRMC_t GPRMCTest[4];//???????????????????????

extern unsigned char GPRMC_Locat_L[11];
extern unsigned char *GPRMC_Locat_P[11];



extern unsigned char GPRMC_Receive();

unsigned char GPRMC_Package_Check();

extern unsigned int GPRMCMessageLen;

#endif
