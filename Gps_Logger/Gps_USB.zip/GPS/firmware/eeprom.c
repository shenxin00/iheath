#include "eeprom.h"
#include <avr/io.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include "lcd.h"

//
// Write address tracks the current write address for handling the
// StartWrite()/Write()/StopWrite() sequence.
//
static unsigned int eepromWriteAddress=0x00;



// spi_xfer - Exchange bytes with the SPI port
// 
// Here is the workhorse routine for this module. spi_xfer will initiate a 
// data transfer on the SPI port. Since the SPI protocol is an 'exchange' 
// protocol, a read and a write operation are identical. 
//
// On input, byte contains the byte value to send OUT the SPI port.
// On exit, the byte shifted in is the return value
//
unsigned char eepromSpiTransfer(unsigned char byte)
{
		 // Shift a byte out, wait for result, return shifted in byte
 		 SPDR = byte;
		 while((SPSR & 0x80) == 0);//SPIF is set!
		 return SPDR;
}

//
// The following two worker routines select and deselect the EEPROM. By 
// raising and lowering the CS line. If you wire up the SPI port differently,
// then put the code in here that maintains the CS line for the EEPROM. 
//
/*void eepromSpiSelect()
{
	   EEPROM_SCE_ON();
}
	   
void eepromSpiDeselect()
{
	   // Raise the CS line
	   EEPROM_SCE_OFF();
}
*/
//
// Several commands are single byte. This routine selects, sends, and deselects
// the EEPROM for single byte commands.
//
unsigned char eepromSpiByteCommand(unsigned char byte)
{
		 EEPROM_SCE_ON();
		 byte = eepromSpiTransfer(byte);
		 EEPROM_SCE_OFF();
		 return byte;
}
	 
//
// This initializes the SPI port to suite the EEPROM part. Should be called
// at the start of your program.
//
void eepromSpiInitialize()
{
	EEPROM_PORT_INI();
	//eepromSpiSet();The speed has been set in lcd.c use lcdSpiSet();
}

//
// This routine sets the block protection level. Check out the docuementation
// for your part. Most have 4 levels of protection (0 to 3), meaning that 
// protection level 3 is all protected, level 2 protects the upper 1/4,
// level 1 protects the upper half, and level 0 leaves everything fair game.
//

void eepromSpiBlockProtection(unsigned char ucLevel)
{
	 ucLevel = ucLevel & 0x03;
	 ucLevel = ucLevel << 2;
	 EEPROM_SCE_ON();
	 eepromSpiTransfer(EEPROM_WRSR);
	 eepromSpiTransfer(ucLevel);	 
	 EEPROM_SCE_OFF();
}

//
// For the most part, to write data to the EEPROM, you want to use the 
// sermem_WriteBlock(...) command. This allows you to write and commit a
// block of memory to the EEPROM. This is useful in most cases. There are, 
// however, cases where you will want to write a stream of data instead.
//
// The serial EEPROM's allow you to send streams of bytes in a write command.
// I have written these routines to allow you access to the serial EEPROM 
// if you are streaming data. The basic sequence is:
//
// sermem_StartWrite(...)
// sermem_Write(...)
// sermem_StopWrite()
//
// Note that to insure that your data is actually committed, you need to call
// StopWrite to end this operation. Otherwise, the last page will not be
// committed to memory.
//
// Note that this sequence cannot be interrupted by other EEPROM operations. 
// Specifically, once StartWrite() has been called, you can only call Write()
// or StopWrite(). Most any other operation will fail because the chip has
// been left in a write mode. 
//

void eepromSpiStartWrite(unsigned int iAddress)
{
	 // StartWrite begins by enabling the EEPROM
	eepromSpiByteCommand(EEPROM_WREN);
	 // Now send the Write command followed by the address, MSB first
	EEPROM_SCE_ON();
	eepromSpiTransfer(EEPROM_WRITE);
	eepromSpiTransfer(iAddress>>8);
	eepromSpiTransfer(iAddress&0xFF);
	// Remember the starting address for the Write command
	eepromWriteAddress = iAddress;
	// StartWrite leaves the EEPROM selected
}
//
// sermem_Write requires that sermem_StartWrite has been called to initiate
// the write operation. To finish, you MUST call sermem_StopWrite
//
void eepromSpiWrite(unsigned char *pBuf,unsigned int cBuf)
{
	 // Using the address in eepromWriteAddress, start sending bytes to the
	 // memory part. After each write, determine if the address has
	 // encountered a page boundary. If so, then handle the write
	 while(cBuf)
	 {
	 	// Send the byte to the part
	 	eepromSpiTransfer(*pBuf);
		cBuf--;
		pBuf++;
		eepromWriteAddress++;
		if((eepromWriteAddress & EEPROM_PAGE_MASK) == 0)
		{
		     // We have page wrapped! 
			 eepromSpiStopWrite();
			 eepromSpiStartWrite(eepromWriteAddress);
		}
	 }
}
void eepromSpiStopWrite(void)
{
	 //
	 // Raise the CS line. That makes the memory part start its write cycle
	 // Then wait for the WIP bit to be cleared
	 //

	 do
	 {
	 	 EEPROM_SCE_OFF();
	 	 // Need to select the EEPROM for the read status operation
	 	 EEPROM_SCE_ON();
	 	 eepromSpiTransfer(EEPROM_RDSR);
		 // The Write In Progress (WIP) flag is bit 1. Wait for it to go off.
	 } while (eepromSpiTransfer(EEPROM_RDSR) & 0x01);
	 EEPROM_SCE_OFF();
	 
	 // Disallow further writes to the EEPROM. Prevents rouge clock signals
	 // from corrupting your data!
	 eepromSpiByteCommand(EEPROM_WRDI);
	 	
}
//
// Here is the workhorse routine!
//
void eepromSpiWriteBlock(unsigned int iAddress,unsigned char *pBuf,unsigned int cBuf)
{
	 eepromSpiStartWrite(iAddress);
	 eepromSpiWrite(pBuf,cBuf);
	 eepromSpiStopWrite();
}

//
// On occasion, you may want to just fill the EEPROM array with a byte
// value. This routine does just that!
//
/*
void eepromSpiFill(unsigned int iAddress,unsigned char byte,unsigned int count)
{
	 eepromSpiStartWrite(iAddress);
	 while(count)
	 {
	 	// Send the byte to the part
	 	eepromSpiTransfer(byte);
		count--;
		eepromWriteAddress++;
		if((eepromWriteAddress & EEPROM_PAGE_MASK) == 0)
		{
		     // We have page wrapped! 
			 eepromSpiStopWrite();
			 eepromSpiStartWrite(eepromWriteAddress);
		}
	 }
	 eepromSpiStopWrite();
}
*/
//
// For the most part, to read data from the EEPROM, you want to use the 
// sermem_ReadBlock(...) command. This allows you to read a
// block of memory from the EEPROM. This is useful in most cases. There are, 
// however, cases where you will want to read a stream of data instead.
//
// The serial EEPROM's allow you to read streams of bytes in a read command.
// I have written these routines to allow you access to the serial EEPROM 
// if you are streaming data. The basic sequence is:
//
// sermem_StartRead(...)
// sermem_Read(...)
// sermem_StopRead()
//
//
// Note that this sequence cannot be interrupted by other EEPROM operations. 
// Specifically, once StartRead() has been called, you can only call Read()
// or StopRead(). Most any other operation will fail because the chip has
// been left in a read mode. 
//

void eepromSpiStartRead(unsigned int iAddress)
{
 	 // StartRead begins by enabling the EEPROM
	 EEPROM_SCE_ON();
	 // Now send the Read command followed by the address, MSB first
	 eepromSpiTransfer(EEPROM_READ);
	 eepromSpiTransfer(iAddress>>8);
	 eepromSpiTransfer(iAddress&0xFF);
}
	 
void eepromSpiRead(unsigned char *pBuf,unsigned int cBuf)
{
	 while(cBuf)
	 {
	 	*pBuf = eepromSpiTransfer(0xFF);
		pBuf++;
		cBuf--;
	 }
}
/*
void eepromSpiStopRead(void)
{
	 EEPROM_SCE_OFF();
}*/

//
// Here is the 'Read' workhorse routine.
//
void eepromSpiReadBlock(unsigned int iAddress,unsigned char *pBuf,unsigned int cBuf)
{
	 eepromSpiStartRead(iAddress);
	 eepromSpiRead(pBuf,cBuf);
	 EEPROM_SCE_OFF();
}



