#ifndef	__KEY_H__
#define	__KEY_H__

#define KEY_MENU	0x37
#define KEY_LEFT	0x2F
#define KEY_RIGHT	0x1F
#define KEY_NULL	0X3F

extern void keyInit(void);
extern unsigned char keyRead(void);
unsigned char keyEvent(unsigned char keyValue);

#endif
