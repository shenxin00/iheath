#include "display.h"
#include "transform.h"
#include "gps.h"
#include "lcd.h"
#include "eeprom.h"
#include "usbconfig.h"
#include "usbtrans.h"
#include "usbdrv.h"
#include "key.h"

#include <util/delay.h>
#include <avr/io.h>

unsigned char displayMode=0x00;
//--------------------------------------------------------
//shoud be read at the init time
unsigned char displayRecordUnit='s';
unsigned char displayRecordFreq=0x0A;//The default is 10s
unsigned int displayRecordAdd=0x00;//0x00保留为系统信息

unsigned char displayRecordStart=false;
unsigned char displayRecordOverflow=false;//---------------------------
//--------------------------------------------------------
/*------Mode00-------
T:00:00:00			F
N:00'00'00
E:000'00'00
V:0.000km/h
C:0.000'
D:00-00-28
---------------------
*/
unsigned char displayMode00(void)
{
	lcdClearBuffer(lcdBuffer);
	lcdWriteString(trans_time(),0,0);
	lcdWriteString(trans_latitude(),1,0);
	lcdWriteString(trans_longitude(),2,0);
	lcdWriteString(trans_speed(),3,0);
	lcdWriteString(trans_course(),4,0);
	lcdWriteString(trans_date(),5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}
/*----Mode10----
	Track	Set
	   Mode
Enetr		Next
----------------
*/
unsigned char displayMode10(void)
{
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)"Track Set Mode",1,0);
	lcdWriteString((const unsigned char *)"         Enter",5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}

/*----Mode11----
Erase the old
	  record ?
Enetr		Next
Yes		No
----------------
*/
unsigned char displayMode11(void)
{
	unsigned char buffer[4]={0};
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)"Erase the old",0,0);
	lcdWriteString((const unsigned char *)"   record ?  ",1,0);
	lcdWriteString((const unsigned char *)"Used: ",3,0);
	displayRecordAdd%=(EEPROM_MESSAGE_SIZE+1);
	buffer[0]=displayRecordAdd/100+'0';
	buffer[1]=displayRecordAdd%100/10+'0';
	buffer[2]=displayRecordAdd%10+'0';
	lcdWriteString((const unsigned char *)buffer,3,6);
	lcdWriteString((const unsigned char *)"/",3,9);
	buffer[0]=EEPROM_MESSAGE_SIZE/100+'0';
	buffer[1]=EEPROM_MESSAGE_SIZE%100/10+'0';
	buffer[2]=EEPROM_MESSAGE_SIZE%10+'0';
	lcdWriteString((const unsigned char *)buffer,3,10);
	lcdWriteString((const unsigned char *)"Yes         No",5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}
/*----Mode12----
 Set Frequent 
 
	___s/m
	
Add         OK
----------------
*/
unsigned char displayMode12(void)
{
	unsigned char frequent[5]={0};
	frequent[0]=displayRecordFreq/10+'0';
	if(frequent[0]=='0')
		frequent[0]=' ';
	frequent[1]=displayRecordFreq%10+'0';
	frequent[2]=' ';
	frequent[3]=displayRecordUnit;
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)" Set Frequent ",1,0);
	lcdWriteString((const unsigned char *)frequent,3,5);//-----------------------------存放频率
	lcdWriteString((const unsigned char *)"Add         OK",5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}
/*----Mode13----
 Start Record? 
 
	___s/m
	
Yes          No
----------------
*/
unsigned char displayMode13(void)
{
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)" Start Record?",1,0);
	lcdWriteString((const unsigned char *)"Yes         No",5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}

/*----Mode20----
 USB Mode 
 

	
Enter       Next
----------------
*/
unsigned char displayMode20(void)
{
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)"   USB Mode   ",1,0);
	//-----------------------------存放频率
	lcdWriteString((const unsigned char *)"         Enter",5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}
/*----Mode21----
 Please link
 the cable

	
Enter       Next
----------------
*/
unsigned char displayMode21(void)
{
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)" Please link  ",1,0);
	lcdWriteString((const unsigned char *)"   the cable! ",2,0);
	//-----------------------------存放频率
	lcdWriteString((const unsigned char *)"Start     Exit",5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}

/*----Mode22----


	GPS=>PC
	
            Exit
----------------
*/
unsigned char displayMode22(void)
{
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)"    GPS=>PC   ",2,0);
	//-----------------------------存放频率
	lcdWriteString((const unsigned char *)"          Exit",5,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}


unsigned char displayError(void)
{
	unsigned char error[4]={0};
	error[0]=displayMode/100+'0';
	error[1]=displayMode%100/10+'0';
	error[2]=displayMode%10+'0';
	lcdClearBuffer(lcdBuffer);
	lcdWriteString((const unsigned char *)"     Error    ",3,0);
	lcdWriteString((const unsigned char *)error,4,0);
	lcdDisplayAll(lcdBuffer);
	return 0;
}

unsigned char display(void)
{
	switch(displayMode)
	{
		case 0x00:displayMode00();break;
		case 0x10:displayMode10();break;
		case 0x11:displayMode11();break;
		case 0x12:displayMode12();break;
		case 0x13:displayMode13();break;
		case 0x20:displayMode20();break;
		case 0x21:displayMode21();break;
		case 0x22:displayMode22();usbPoll();break;//while(PINC!=KEY_RIGHT){usbPoll();};keyRead();break;
		default: displayError();
	}
	return 0;
}
/*----------------------------------------------------------*/
//杂七杂八
unsigned char displayRecordMode(void)
{
	if(displayRecordUnit=='s')
	{
		switch(displayRecordFreq)
		{
			case 1:		displayRecordFreq=10;break;
			case 10:	displayRecordFreq=30;break;
			case 30:	displayRecordUnit='m';displayRecordFreq=1;break;
			default: 	displayRecordUnit='s';displayRecordFreq=1;
		}
		return 0;
	}
	if(displayRecordUnit=='m')
	{
		switch(displayRecordFreq)
		{
			case 1:		displayRecordFreq=5;break;
			case 5:		displayRecordFreq=10;break;
			case 10:	displayRecordUnit='s';displayRecordFreq=1;break;
			default: 	displayRecordUnit='s';displayRecordFreq=1;
		}	
		return 0;
	}displayMode21();
	return 0;
}

unsigned char displayRecordOvi(void)
{
	unsigned int temp=0x00;
	unsigned char i;
	if(displayRecordAdd==0x01)//第一次应当更新信息
	{
		for(i=0;i<6;i++)
		{
			GPSOviData[i]=GPRMC.GPRMC_UTCdate[i];
		}
		for(i=0;i<6;i++)
		{
			GPSOviData[6+i]=GPRMC.GPRMC_UTCTime[i];
		}
		temp=displayRecordAdd;
		for(i=0;i<6;i++)
		{
			GPSOviData[29-i]=temp%10+'0';
			temp/=10;
		}			
	}
	for(i=0;i<6;i++)
	{
		GPSOviData[12+i]=GPRMC.GPRMC_UTCdate[i];
	}
	for(i=0;i<6;i++)
	{
		GPSOviData[18+i]=GPRMC.GPRMC_UTCTime[i];
	}
	temp=displayRecordAdd;
	for(i=0;i<6;i++)
	{
		GPSOviData[35-i]=temp%10+'0';
		temp/=10;
	}
	GPSOviData[36]=0;
	return 0;
}

unsigned char displayReadOvi(void)
{
	unsigned char i;
	unsigned int high=0,low=0;
//	uchar usbOviData[USB_OVI_REP_LEN]="880819101112100311114930000001000010";//利用格林威治时间
//								       yymmddhhmmssyymmddhhmmssllllllhhhhhh
//								       012345678901234567890123456789012345678		total:36
//								       0         1         2         3
	eepromSpiReadBlock((unsigned int)0,(unsigned char *)GPSOviData,USB_OVI_REP_LEN);
	for(i=0;i<6;i++)
	{
		low*=10;
		low+=GPSOviData[24+i]-'0';
	}
	for(i=0;i<6;i++)
	{
		high*=10;
		high+=GPSOviData[30+i]-'0';
	}
	displayRecordAdd=high-low+1;
	return 0;
}

unsigned char displayRecordFun(void)
{
	if(displayRecordStart==false)
		return 0;
	if(displayRecordOverflow==true)							//数据区已存满
		return 0;
	if(GPRMC.GPRMC_State[0]=='V')//this code should be masked at the debug
		return 0;
	static unsigned char latestSecond=0x00,latestMinute=0x00;//上一次记录的时间
	unsigned char flag=false,second=0x00,minute=0x00;
	minute=(GPRMC.GPRMC_UTCTime[2]-'0')*10;					//判断是否为旧数据
	minute+=(GPRMC.GPRMC_UTCTime[3]-'0');
	second=(GPRMC.GPRMC_UTCTime[4]-'0')*10;
	second+=(GPRMC.GPRMC_UTCTime[5]-'0');
	if(latestSecond==second && latestMinute==minute)			//该数据为旧数据
		return 0;
	if(displayRecordUnit=='s')
	{
		if(latestSecond==second)
			return 0;
		switch(displayRecordFreq)
		{
			case 1:		flag=true;break;
			case 10:	if(second%10==0)flag=true;break;
			case 30:	if(((second==00) || (second==30)))flag=true;break;
			default: 	flag=false;
		}
	}
	if(displayRecordUnit=='m')
	{
		if(latestSecond==second || latestMinute==minute)			//该数据为旧数据
			return 0;
		switch(displayRecordFreq)
		{
			case 1:		if(second==0)flag=true;break;				
			case 5:		if((minute%10==0)||(minute%10==5))flag=true;break;
			case 10:	if(minute%10==0)flag=true;break;
			default:	flag=false;
		}
	}
	latestSecond=second;
	latestMinute=minute;
	if(flag==true)
	{
		if(displayRecordAdd<EEPROM_MESSAGE_SIZE)
			displayRecordAdd++;
		else
		{
			displayRecordOverflow=true;
			return 0;
		}
		LCD_LIGHT_ON();
		displayRecordOvi();
		eepromSpiWriteBlock((unsigned int)0,(unsigned char *)GPSOviData,USB_OVI_REP_LEN);
		eepromSpiWriteBlock((unsigned int)displayRecordAdd*EEPROM_PAGE_SIZE,(unsigned char *)&GPRMC,USB_GPS_REP_LEN);
		_delay_ms(10);
		LCD_LIGHT_OFF();
	}
	return 0;
}


