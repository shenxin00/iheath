#ifndef __EEPROM_H__
#define __EEPROM_H__



#define 	EEPROM_SCE			2	//B
#define		EEPROM_SCK			5	//B
#define		EEPROM_MISO			4	//B
#define		EEPROM_MOSI			3	//B

#define 	EEPROM_WREN  		0x06 	//Set Write Enable Latch
#define 	EEPROM_WRDI  		0x04 	//Reset Write Enable Latch
#define 	EEPROM_RDSR  		0x05 	//Read Status Register
#define 	EEPROM_WRSR  		0x01		//Write Status Register
#define 	EEPROM_READ  		0x03 	//Read Data from Memory Array
#define 	EEPROM_WRITE 		0x02 	//Write Data to Memory Array

#define		EEPROM_PAGE_SIZE 				64
#define		EEPROM_SIZE		 				16384//byte
#define		EEPROM_PAGE_MASK 				(EEPROM_PAGE_SIZE-1)
#define		EEPROM_MESSAGE_SIZE				255	//the first 64 byte is for overview

#define		EEPROM_SCE_ON()					PORTB &=~ (1<<EEPROM_SCE);PORTB|=(1<<LCD_SCE)
#define		EEPROM_SCE_OFF()				PORTB |= (1<<EEPROM_SCE)

#define		EEPROM_IS_READY(x)				(((x)&0x01)==0)?1:0
#define		EEPROM_IS_WRITEEN(x)			(((x)&0x02)==1)?1:0	

#define		eepromSpiSet					lcdSpiSet	//此处定义与LCDSPI接口寄存器配置相同，同样采用1/4fosc

#define		EEPROM_PORT_INI()				DDRB|=((1<<EEPROM_SCE)|(1<<EEPROM_SCK)|(1<<EEPROM_MOSI));\
											DDRB&=~((1<<EEPROM_MISO))
								
#define		EEPROM_TRANSFER_COMPLETE		0x08
#define		EEPROM_BUSY						0X01
#define		EEPROM_OUT_OF_RANGE				0X02

//extern void eepromSpiSelect();
//extern void eepromSpiDeselect();

extern void eepromSpiInitialize();
//----------------------------------------------------------------------------
extern void eepromSpiStartWrite(unsigned int iAddress);
extern void eepromSpiWrite(unsigned char *pBuf,unsigned int cBuf);
extern void eepromSpiStopWrite(void);
extern void eepromSpiWriteBlock(unsigned int iAddress,unsigned char *pBuf,unsigned int cBuf);
//----------------------------------------------------------------------------
extern void eepromSpiFill(unsigned int iAddress,unsigned char byte,unsigned int count);
//----------------------------------------------------------------------------
extern void eepromSpiStartRead(unsigned int iAddress);
extern void eepromSpiRead(unsigned char *pBuf,unsigned int cBuf);
extern void eepromSpiStopRead(void);
//----------------------------------------------------------------------------
extern void eepromSpiReadBlock(unsigned int iAddress,unsigned char *pBuf,unsigned int cBuf);
//------------------------------------------------------------------------------
extern void eepromSpiBlockProtection(unsigned char ucLevel);

unsigned char eepromSpiTransfer(unsigned char byte);
unsigned char eepromSpiByteCommand(unsigned char byte);

//extern unsigned int eepromWriteAddress;

#endif
