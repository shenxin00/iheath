#ifndef __UART_H__
#define __UART_H__


#ifndef F_CPU
#define F_CPU 12000000UL 
#endif

#ifndef BAUD
#define BAUD   4800
#endif

#define R_UBRR (F_CPU/BAUD/16-1)

extern void USART_Init( unsigned int baud );
extern void USART_Transmit( unsigned char data );
extern unsigned char USART_Receive( void );

#endif
