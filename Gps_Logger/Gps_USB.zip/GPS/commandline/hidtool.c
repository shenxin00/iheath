/* Name: hidtool.c
 * Project: hid-data example
 * Author: Christian Starkjohann
 * Creation Date: 2008-04-11
 * Tabsize: 4
 * Copyright: (c) 2008 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: GNU GPL v2 (see License.txt), GNU GPL v3 or proprietary (CommercialLicense.txt)
 * This Revision: $Id: hidtool.c 723 2009-03-16 19:04:32Z cs $
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "hiddata.h"
#include "../firmware/usbconfig.h"  /* for device VID, PID, vendor name and product name */

/* ------------------------------------------------------------------------- */

static char *usbErrorMessage(int errCode)
{
static char buffer[80];

    switch(errCode){
        case USBOPEN_ERR_ACCESS:      return "Access to device denied";
        case USBOPEN_ERR_NOTFOUND:    return "The specified device was not found";
        case USBOPEN_ERR_IO:          return "Communication error with device";
        default:
            sprintf(buffer, "Unknown USB error %d", errCode);
            return buffer;
    }
    return NULL;    /* not reached */
}

static usbDevice_t  *openDevice(void)
{
usbDevice_t     *dev = NULL;
unsigned char   rawVid[2] = {USB_CFG_VENDOR_ID}, rawPid[2] = {USB_CFG_DEVICE_ID};
char            vendorName[] = {USB_CFG_VENDOR_NAME, 0}, productName[] = {USB_CFG_DEVICE_NAME, 0};
int             vid = rawVid[0] + 256 * rawVid[1];
int             pid = rawPid[0] + 256 * rawPid[1];
int             err;

    if((err = usbhidOpenDevice(&dev, vid, vendorName, pid, productName, 0)) != 0){
        fprintf(stderr, "error finding %s: %s\n", productName, usbErrorMessage(err));
        return NULL;
    }
    return dev;
}



static unsigned int printOverview(char *buffer,int _len)
{
	//yymmddhhmmssyymmddhhmmssllllllhhhhhh
	//123456789012345678901234567890123456
	//0		   1		 2		   3
	//
	unsigned int count=0,dataLen,numberl,numberh;
	char temp[10]={1};
	fprintf(stdout,"====================================================\n");
	fprintf(stdout,"The total size of the overview package is %d.\n",_len);
	fprintf(stdout,"====================================================\n");
	fprintf(stdout,"From:\t");
	fprintf(stdout,"%c%c - ",buffer[count+1],buffer[count+2]);count+=2;	//buffer[0] is report ID
	fprintf(stdout,"%c%c - ",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c	",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c : ",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c : ",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c	",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"\nTo:\t\t");
	fprintf(stdout,"%c%c - ",buffer[count+1],buffer[count+2]);count+=2;	//buffer[0] is report ID
	fprintf(stdout,"%c%c - ",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c	",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c : ",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c : ",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"%c%c	\n",buffer[count+1],buffer[count+2]);count+=2;
	fprintf(stdout,"Total:\t");
	strncpy(temp,&buffer[25],6);
	numberl=(unsigned int)strtol(temp,NULL,10);
	strncpy(temp,&buffer[31],6);
	numberh=(unsigned int)strtol(temp,NULL,10);
	dataLen=numberh-numberl+1;
	if(dataLen<0)
	{
		dataLen=0;
	}
	fprintf(stdout,"%u\trecord\n",dataLen);
	fprintf(stdout,"====================================================\n");
	return dataLen;
}

/* ------------------------------------------------------------------------- */

static void usage(char *myName)
{
    fprintf(stderr, "usage:\n");
    fprintf(stderr, "  %s overview\n", myName);
    fprintf(stderr, "  %s write <listofbytes>\n", myName);
}

int main(int argc, char **argv)
{
usbDevice_t *dev;
char        buffer[255];    /* room for dummy report ID */
int         err;

    if(argc < 2)
    {
        usage(argv[0]);
        exit(1);
    }
    if((dev = openDevice()) == NULL)
        exit(1);
    int		len=sizeof(buffer);
    if(strcmp(argv[1], "overview") == 0)
    {
    	len=USB_OVI_REP_LEN+1;
        if((err = usbhidGetReport(dev, USB_OVI_REP_NUM , buffer, &len, 1)) != 0)
        {
            fprintf(stderr, "error reading data: %s\n", usbErrorMessage(err));
        }
        else
        {	
        	printOverview(buffer,len);
        }
    }
    else if(strcmp(argv[1],"readall")==0)
    {
    	unsigned int dataLen;
    	int i;
    	len=USB_OVI_REP_LEN+1;
        if((err = usbhidGetReport(dev, USB_OVI_REP_NUM , buffer, &len, 1)) != 0)
        {
            fprintf(stderr, "error reading data: %s\n", usbErrorMessage(err));
        }
        else
        {	
        	dataLen=printOverview(buffer,len);
        	if(dataLen==0)
        		return 1;
        	len=USB_GPS_REP_LEN+1;
    		for(i=1;i<=dataLen;i++)
    		{
    			if((err = usbhidGetReport(dev, USB_GPS_REP_NUM , buffer, &len, i)) != 0)
      		  	{
         		   	fprintf(stderr, "error reading data: %s\n", usbErrorMessage(err));
        		}
       			else
        		{	
        			buffer[USB_GPS_REP_LEN]='\0';
        			fprintf(stdout,"%d:\t%s\n",i,buffer+1);
        			//fprintf(stdout,"the len is %d\n",len);
        		}
       		 }
        }
    }
    else
    {
        usage(argv[0]);
        exit(1);
    }
    usbhidCloseDevice(dev);
    return 0;
}

/* ------------------------------------------------------------------------- */
